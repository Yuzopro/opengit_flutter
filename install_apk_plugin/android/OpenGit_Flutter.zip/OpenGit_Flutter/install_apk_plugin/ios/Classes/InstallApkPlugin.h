#import <Flutter/Flutter.h>

@interface InstallApkPlugin : NSObject<FlutterPlugin>
@end
