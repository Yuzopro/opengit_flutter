//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <install_apk_plugin/InstallApkPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [InstallApkPlugin registerWithRegistrar:[registry registrarForPlugin:@"InstallApkPlugin"]];
}

@end
