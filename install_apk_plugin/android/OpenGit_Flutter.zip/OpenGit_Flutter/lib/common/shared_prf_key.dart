class SharedPrfKey {
  static const String SP_KEY_TOKEN = "sp_token";
  static const String SP_KEY_USER_INFO = "sp_user_info";
  static const String SP_KEY_THEME_COLOR = "sp_theme_color";
  static const String SP_KEY_LANGUAGE_COLOR = "sp_language_color";
}