abstract class IBaseView {
  showLoading();

  hideLoading();

  showToast(String message);
}
