// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'license_bean.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

License _$LicenseFromJson(Map<String, dynamic> json) {
  return License(json['name'] as String);
}

Map<String, dynamic> _$LicenseToJson(License instance) =>
    <String, dynamic>{'name': instance.name};
