import 'package:flutter/material.dart';

class RepositoryContributorPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _RepositoryContributorPageState();
  }
}

class _RepositoryContributorPageState extends State<StatefulWidget> {
  @override
  Widget build(BuildContext context) {
    return new Center(
      child: Text("RepositoryContributorPage"),
    );
  }
}