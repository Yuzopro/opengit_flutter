class ResponseResultData {
  var data;
  bool result;
  int code;

  ResponseResultData(this.data, this.result, this.code);
}
